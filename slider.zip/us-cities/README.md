# US Cities

A Pen created on CodePen.io. Original URL: [https://codepen.io/jeyefendi/pen/YzLoqOg](https://codepen.io/jeyefendi/pen/YzLoqOg).

>Marathon of Vladilen Minin - Day 1st

Slider on pure JS & CSS from scratch with smooth animation.